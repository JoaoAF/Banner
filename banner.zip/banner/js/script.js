 $('#consulta').click(function(consultaBtn){
            consultaBtn.preventDefault;
            var lastName = $('#last_name:text');
            if (lastName.val() == "") {
            alert('Por favor preencha o campo para a consulta');
            } else {
            $('#form_consulta').submit();
            }

        });

 $(function(){
    $(".button-collapse").sideNav();
});
