@extends('principal')
@section('conteudo')
<section class="main-content">
    <div class="page-header">
        <h1>Consulta por campanha</h1>
    </div>
    <form class="form-pesquisa">
        <input name="campanha" type="text" class="form-control input-pesquisa" placeholder="Digite o nome da campanha">
        <button type="submit" class="btn btn-primary">Pesquisar</button>
    </form>
        @if(Request::input('campanha'))
        <table class="table table-hover">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Campanha</th>
                <th>Cliente</th>
            </tr>
        </thead>
        <tbody>
            @foreach($clienteCampanha as $c)
                <tr>
                    <td> {{$c->nome}} </td>
                    <td> {{$c->email}} </td>
                    <td> {{$c->telefone}} </td>
                    <td><b><i><u>{{$c->campanha}}</u></i></b></td>
                    <td> {{$c->cliente_banner}} </td>
                </tr>
            @endforeach
            @endif
        </tbody>
    </table>
</section>
@stop

