@extends('principal')
@section('conteudo')
<section class="main-content">
    <div class="page-header">
        <h1>Consulta por cliente</h1>
    </div>
    <form class="form-pesquisa">
        <input name="cliente_banner" type="text" class="form-control input-pesquisa" placeholder="Digite o nome do cliente">
        <button type="submit" class="btn btn-primary">Pesquisar</button>
    </form>
    @if(Request::input('cliente_banner'))
    <table class="table table-hover">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Campanha</th>
                <th>Cliente</th>
            </tr>
        </thead>
        <tbody>
            @foreach($cliente as $c)
                <tr>
                    <td> {{$c->nome}} </td>
                    <td> {{$c->email}} </td>
                    <td> {{$c->telefone}} </td>
                    <td> {{$c->campanha}} </td>
                    <td><b><i><u>{{$c->cliente_banner}}</u></i><b></td>
                </tr>
            @endforeach
             @endif
        </tbody>
    </table>
</section>
@stop