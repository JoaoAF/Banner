<!DOCTYPE html>
<html lang="pt-br">
<head>
    <title>Projeto Banner</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/app.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<header>
<div class="container">
    <div class="jumbotron">
        <a class="link-header" href="banner/public/"><h1>Projeto Banner</h1></a>
    </div>
    <nav class="navgation">
        <ul class="nav nav-pills">
            <li><a href="banner/public/">Projeto Banner</a></li>
            <li><a href="/banner/public/listagemCampanha">Listagem por campanha</a></li>
            <li><a href="/banner/public/listagemCliente">Listagem por cliente</a></li>
        </ul>
    </nav>
</div>
</header>
    @yield('conteudo')
</body>
</html>