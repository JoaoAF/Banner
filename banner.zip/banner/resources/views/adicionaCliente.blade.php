@extends('principal')
@section('conteudo')

    <section class="main-content">
        <h1>Olá eu sou o adiciona.</h1>
    </section>

@stop