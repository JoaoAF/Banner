@extends('principal')
@section('conteudo')
    <section class="main-content">
    <h1>Projeto Banner</h1>
    </section>
@stop