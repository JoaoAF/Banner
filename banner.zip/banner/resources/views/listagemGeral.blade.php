@extends('principal')
@section('conteudo')
<section class="main-content">
<div class="page-header">
    <h1>Listagem geral</h1>
</div>
    <table class="table table-hover">
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Campanha</th>
                <th>Cliente</th>
            </tr>
        </thead>
        <tbody>
            @foreach($clientes as $c)
                <tr>
                    <td> {{$c->nome}} </td>
                    <td> {{$c->email}} </td>
                    <td> {{$c->telefone}} </td>
                    <td> {{$c->campanha}} </td>
                    <td> {{$c->cliente_banner}} </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</section>
@stop