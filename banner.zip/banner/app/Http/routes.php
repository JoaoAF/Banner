<?php

Route::get('/', 'ClienteController@listagemGeral');
Route::get('/listagemGeral', 'ClienteController@listagemGeral');
Route::get('/listagemCliente', 'ClienteController@listagemCliente');
Route::get('/listagemCampanha', 'ClienteController@listagemCampanha');
Route::get('/adiciona', 'ClienteController@adicionaCliente');