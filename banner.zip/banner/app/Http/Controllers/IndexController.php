<?php namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

class IndexController extends Controller{

    public function paginaInicial(){

        return view('paginaInicial');

    }
}