<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Request;

class ClienteController extends Controller{

    public function adicionaCliente(){
        $nome = Request::input('nome');
        $email = Request::input('email');
        $telefone = Request::input('telefone');
        $cliente = Request::input('cliente_banner');
        $campanha = Request::input('campanha');

        DB::insert("INSERT INTO Cliente (nome, email, telefone, cliente_banner, campanha)
                         VALUES ('$nome', '$email', '$telefone', '$cliente', '$campanha')");

        return view('adicionaCliente');
    }

    public function listagemGeral(){
        $clientes = DB::select('select * from Cliente order by id desc');
        return view('listagemGeral')->with('clientes', $clientes);

    }

    public function listagemCliente(){
        $cliente = Request::input('cliente_banner');
        $clientes = DB::select("select * from Cliente where cliente_banner like '%$cliente%' order by id desc");
        return view('listagemCliente')->with('cliente', $clientes);
    }

     public function listagemCampanha(){
        $campanha = Request::input('campanha');
        $clientes = DB::select("select * from Cliente where campanha like '%$campanha%' order by id desc");
        return view("listagemCampanha")->with('clienteCampanha', $clientes);
    }
}